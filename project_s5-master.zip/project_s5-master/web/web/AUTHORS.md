# The Core Team

* [Chris Kacerguis](//github.com/chriskacerguis)
* [Phil Sturgeon](//github.com/philsturgeon)

### Special Thanks To

* [Fabian Hanisch](//github.com/Hanisch-IT)

*For a list of people who have contributed to the codebase, see [GitHub's list of contributors](https://github.com/chriskacerguis/codeigniter-restserver/graphs/contributors).  Anyone who has contributed please do a PR and add to this file.*
